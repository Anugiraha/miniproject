package AtmHistory;

import java.util.Scanner;

public class AtmOperations {
	int amount,balance;
	int depositamount;
	int withdrawamount;

	Scanner sc=new Scanner (System.in);
	public void CheckAvailablebalance() {
		amount =amount+depositamount-withdrawamount;
		System.out.println("Avaliable current balance:" +amount);
		
	}
	public void DepositeAmount() {
		System.out.println("enter the deposit amount:");
	 	depositamount=sc.nextInt();
		amount=amount+depositamount;
		System.out.println("Amount should be deposit successfully");
		System.out.println("Avaliable balance amount="+amount);
	}
	public void WithdrawAmount() {
		System.out.println("enter the withdraw amount:");
		withdrawamount=sc.nextInt();
		if(amount>=withdrawamount) {
			amount=amount-withdrawamount;
			System.out.println("please collect your money");
		}else {
			System.out.println("sorry! Insufficient balance");
			System.out.println(amount);
		}
	}
	public void CheckBalance() {
		amount = depositamount-withdrawamount;
		System.out.println("total balance in your account:"+amount);
	}
		
    public void Exit() {
	System.out.println("Exit");
	System.out.println("Thank you");
	System.out.println("Visit Again");
	System.exit(0);
}
}
	

