package AtmHistory;

import java.util.Scanner;

public class AtmMachine {
	
	public static void main(String[] args) {
		int balance=0;
		int withdrawamount,depositamount;
		AtmOperations Atmop=new AtmOperations();
		Scanner sc=new Scanner(System.in);
			int pinno=1234;
			System.out.println("******Welcome to ATM******");
			System.out.println("Check Pinno");
			System.out.println("Enter the pin number");
			int pin=sc.nextInt();
			if(pinno==pin) {
				System.out.println("Valid pin number");
				}else {
					System.out.println("Incorrect pin number");
				}
			System.out.println("****@MainMenu@****");
		while(true) {
			
			System.out.println("1.Check Available balance");
			System.out.println("2.Deposite");
			System.out.println("3.Withdraw");
			System.out.println("4.Check Balance");
			System.out.println("5.Exit");
			System.out.println("Select the appropriate option you want to perform");
			int choice=sc.nextInt();
			switch(choice) {
			
			case 1:
				Atmop.CheckAvailablebalance();
				break;
			case 2:
				Atmop.DepositeAmount();
				break;
			case 3:
				Atmop.WithdrawAmount();
				break;
			case 4:
				Atmop.CheckBalance();
				break;
			case 5:
				Atmop.Exit();
				System.exit(0);
				break;
				
			}
		}
	}
}
